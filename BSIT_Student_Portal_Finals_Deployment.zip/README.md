# BSIT Student Portal — IT 11 Finals Deployment

## Files
- `index.html` — complete responsive student portal prototype
- `firebase.json` — Firebase Hosting configuration

## Features
- Student registration and sign-in demo
- Student profile with course, year level, section, contact, address, and optional profile photo
- Subjects and grade entry
- Weighted grade formula: attendance 10%, quizzes 10%, performance tasks 20%, prelim 20%, midterm 20%, final exam 20%
- Academic report with print option
- Browser localStorage persistence

## Important limitations
This is a front-end prototype for a school project. Accounts and grades are stored in the browser only; passwords are not securely protected and data does not sync across devices. Do not use real sensitive information. For a production portal, implement Firebase Authentication and Cloud Firestore with security rules.

## Deploy to Firebase Hosting
1. Install Node.js LTS from https://nodejs.org/ and Git from https://git-scm.com/ if needed.
2. Open a terminal in this folder.
3. Run `npm install -g firebase-tools`
4. Run `firebase login`
5. Run `firebase init hosting`, select your Firebase project, set public directory to `.`, configure as a single-page app: `No`, and do not overwrite `index.html` if prompted.
6. Run `firebase deploy --only hosting`
7. Open the Hosting URL shown in the terminal.

## Push to GitHub
Create an empty repository on https://github.com/new. Then run these commands from this folder, replacing YOUR-USERNAME and YOUR-REPOSITORY:
```
git init
git add .
git commit -m "Add BSIT Student Portal"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
